function myFunction3() {
   document.getElementById("demo").innerHTML = "JavaScript e jashtme - Paragrafi ndryshoi.";
}